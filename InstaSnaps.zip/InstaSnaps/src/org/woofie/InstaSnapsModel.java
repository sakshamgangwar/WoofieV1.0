/**
 * Woofie Web Application
 */
package org.woofie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.*;

public class InstaSnapsModel {

	ArrayList<String> urls = null;
    LinkedHashMap<String, String> cache;
	Integer avgLikes = 0;
	Integer totLikes = 0;
	Integer NUM_PICS;
	Integer NUM_PAGES;
	int[] likes;
    private static final Integer maxSizeCache = 1000;
				
	private final static String jsonResponseFormat = "{\n"
			+ "    \"urls\":  [\n" + "                {\n"
			+ "                    \"link\": \"url0\"\n"
			+ "                },\n" + "                {\n"
			+ "                    \"link\": \"url1\"\n"
			+ "                },\n" + "                {\n"
			+ "                    \"link\": \"url2\"\n"
			+ "                }                 \n" + "            ]\n" + "}";

	InstaSnapsModel() {
		NUM_PICS = 3;
		//Using a LRU (Least Recently Used) based cache using a Linked Hash Map
        cache = new LinkedHashMap(maxSizeCache, .75F, true) {
            protected boolean removeEldestEntry(Map.Entry eldest) {
                return size() > maxSizeCache;
            }
        };
	}

	public String search(String hashtags) throws IOException {
		System.out.println("Searching for images with #" + hashtags + "...");
		String responseStr = null;
		String url = "https://api.instagram.com/v1/tags/"
				+ hashtags
				+ "/media/recent?access_token=40480112.1fb234f.4866541998fd4656a2e2e2beaa5c4bb1";
		
		String jsonResponse = getResponseViaGET(url);

		System.out.println("jsonResponse : " + jsonResponse);

		String cached = cache.get(hashtags);
		if(cached != null){
			System.out.println("Results returned from cache");
			return cached;
		}

		NUM_PAGES = 200;
		likes = new int[NUM_PICS];
		urls = new ArrayList<String>();
		processImages(jsonResponse);
		if (urls.size() == 0) {
			responseStr = "No URLs found.";
			return responseStr;
		}

		System.out.println("urls : " + urls);
		responseStr = jsonResponseFormat;
		for (int i = 0; i < urls.size(); i++) {
			String urlPlace = "url" + i;
			responseStr = responseStr.replace(urlPlace, urls.get(i));
		}
		
		cache.put(hashtags, responseStr);
		
		System.out.print("Likes : ");
		for(int i=0; i<NUM_PICS; i++){
			System.out.print(likes[i]+",");
		}
		
		return responseStr;
	}

	public void processImages(String response) {
		JSONObject jsonObj = null;
		String nextPageUrl = null;

		try {
			jsonObj = new JSONObject(response);
		} catch (JSONException ex) {
			System.out.println("Yikes, hit the error: "
					+ ex.getLocalizedMessage());
			ex.printStackTrace();
		}

		JSONArray arr = null;
		try {
			arr = jsonObj.getJSONArray("data");
			int len = arr.length();
			int count = 0;
			for (int i = 0; i < len; i++) {
				int numLikes = arr.getJSONObject(i).getJSONObject("likes")
						.getInt("count");
				String url = arr.getJSONObject(i).getString("link");
				
				if (urls.size() >= NUM_PICS && !urls.contains(url)){
					int minIndex = getMinLikesIndex();
					if (numLikes > likes[minIndex]){
						urls.remove(minIndex);
						urls.add(url);
						likes[minIndex] = numLikes;
					}
				}		
				else{
					urls.add(url); 
					likes[count++] = numLikes;
				}
			}
			
			nextPageUrl = jsonObj.getJSONObject("pagination").getString("next_url");
			if(nextPageUrl != null && --NUM_PAGES > 0){
				String jsonResponse = getResponseViaGET(nextPageUrl);
				if(jsonResponse != null)
					processImages(jsonResponse);
			}
			
		} catch (Exception ex) {
			System.out.println("Yikes, hit the error: "
					+ ex.getLocalizedMessage());
			ex.printStackTrace();
		}
	}
	
	private int getMinLikesIndex(){
		int minIndex = 0;
		int min = Integer.MAX_VALUE;
		for(int i=0; i<NUM_PICS; i++){
			if(likes[i] < min){
				min = likes[i];
				minIndex = i;
			}
		}
		return minIndex;
	}

	public String getResponseViaGET(String url) throws MalformedURLException,
			ProtocolException {
		URL obj = new URL(url);
		StringBuilder result = null;
		try {
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					con.getInputStream()));
			String inputLine;
			result = new StringBuilder();

			while ((inputLine = in.readLine()) != null) {
				result.append(inputLine);
			}
			in.close();
		} catch (IOException e) {
			return null;
		}
		return result.toString();
	}
}