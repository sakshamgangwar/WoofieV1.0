/**
 * Woofie Web Application
 */
package org.woofie;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class InstaSnapsServlet extends HttpServlet {

	InstaSnapsModel ism = null;

	@Override
	public void init() {
		ism = new InstaSnapsModel();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// get the hashtags searched for
		String hashtags = request.getParameter("hashtags");

		//Prepare the JSON response.
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		StringBuffer sb = new StringBuffer();

		if (hashtags != null) {
			try {
				String responseStr = ism.search(hashtags);
				sb.append(responseStr);
			} catch (IOException e) {
			} finally {
				out.println(sb.toString());
				out.flush();
			}
		}
	}
}
